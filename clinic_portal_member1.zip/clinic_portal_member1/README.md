# Digital Health Clinic & Diagnostic Lab Portal: Member 1 package

## Folder layout
- `database/` SQL scripts (MySQL 8.0.16+)
  - `01_schema_ddl.sql` 10-table schema, constraints, slot-time CHECK
  - `03_procedures_functions.sql` sp_book_appointment, sp_generate_or_finalize_bill, fn_lab_total
  - `06_backend_tests.sql` constraint, procedure, transaction, cascade/restrict tests (test evidence)
  - `07_migration_slot_check.sql` adds the slot rule to an EXISTING database (skip on a fresh build)
  - NOT included here (Member 2): `02_triggers.sql`, `04_views_queries.sql`, `05_sample_data.sql`
- `app/` Streamlit code: `reception_tab.py`, `doctor_tab.py` (Member 1); `app.py`, `db_connection.py` (skeletons; Member 3 owns the real ones); `requirements.txt`
- `docs/` report material: `Member1_Documentation.md` (ER view, handoff, tests, viva), `Normalization_and_Design_Decisions.md`, `ER_Diagram_Chen.drawio` / `.svg`

## Run order on a clean database
1. `01_schema_ddl.sql`, then `05_sample_data.sql`, then `03_procedures_functions.sql`, then `02_triggers.sql`, then `04_views_queries.sql`
2. Optional: `mysql -u root -p --force --table clinic_portal < 06_backend_tests.sql`
3. App: `pip install -r app/requirements.txt`, set `DB_PASSWORD`, then `streamlit run app/app.py`

Existing database that predates the slot rule: run `07_migration_slot_check.sql`, then re-run `03_procedures_functions.sql`.

## Status
The Python files are syntax-checked only. Nothing has been run against MySQL yet, so run and test everything before submitting.
